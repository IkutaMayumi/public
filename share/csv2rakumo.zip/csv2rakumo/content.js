chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'fillForm') {
    const data = request.data;
    console.log("受け取ったデータ:", data);

    for (const key in data) {
      // key: CSVの項目名 (e.g., "申請者名")
      // data[key]: 入力したい値 (e.g., "谷 理恵子")
      fillField(key, data[key]);
    }
  }
});

function fillField(key, value) {
  // 画面に表示されているすべての要素を取得
  const allElements = document.querySelectorAll('body *');
  let targetLabel = null;

  // 画面上のテキストとCSVの項目名が完全に一致する要素を探す
  for (const el of allElements) {
    // 要素の子要素のテキストは含まず、その要素自身のテキストのみを比較
    const elementText = Array.from(el.childNodes)
      .filter(node => node.nodeType === Node.TEXT_NODE)
      .map(node => node.textContent.trim())
      .join('');
    
    if (elementText === key) {
      targetLabel = el;
      break;
    }
  }

  if (targetLabel) {
    console.log(`✅ 項目「${key}」のラベル要素が見つかりました。`);
    // 見つけたラベル要素から、関連する入力フィールドを探す
    const inputField = findAssociatedInput(targetLabel);

    if (inputField) {
      console.log(`✅ 項目「${key}」の入力フィールドを発見。値を設定します。`);
      inputField.value = value;
      // Reactなどのフレームワーク用にイベントを能動的に発火させ、変更を検知させる
      inputField.dispatchEvent(new Event('input', { bubbles: true }));
      inputField.dispatchEvent(new Event('change', { bubbles: true }));
    } else {
      console.warn(`❌ 項目「${key}」の入力フィールドが見つかりませんでした。`);
    }
  } else {
    console.warn(`❌ 項目「${key}」のラベルが見つかりませんでした。`);
  }
}

/**
 * ラベル要素から関連する入力フィールド（input, textarea, select）を探す関数
 * ラベルと入力欄が共通の親要素に囲まれていることを想定して探索する
 */
function findAssociatedInput(labelElement) {
  let currentElement = labelElement;
  // 5階層上まで親をたどって探索
  for (let i = 0; i < 5 && currentElement; i++) {
    // 現在の要素（またはその親）の兄弟要素も含めて入力欄を探す
    const container = currentElement.parentElement;
    if (container) {
      const input = container.querySelector('input, textarea, select');
      if (input) {
        return input;
      }
    }
    currentElement = currentElement.parentElement;
  }
  
  console.log(`詳細探索: ${labelElement.textContent.trim()} の関連フィールドが見つかりません。`);
  return null;
}
