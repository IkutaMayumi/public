document.getElementById('fileInput').addEventListener('change', (event) => {
  const file = event.target.files[0];
  if (!file) {
    document.getElementById('fileName').textContent = 'ファイルが選択されていません';
    return;
  }
  
  document.getElementById('fileName').textContent = `選択中: ${file.name}`;

  // Papa Parseを使ってCSVファイルを解析
  Papa.parse(file, {
    header: false,
    skipEmptyLines: true,
    complete: (results) => {
      const data = processCsvData(results.data);
      fillForm(data);
    },
    error: (error) => {
      alert('CSVファイルの解析に失敗しました。');
      console.error('CSV Parse Error:', error);
    }
  });
});

/**
 * Papa Parseで解析された2次元配列のデータを
 * {キー: 値} のオブジェクトに変換する
 */
function processCsvData(rows) {
  const data = {};
  let lastKey = null;

  for (const row of rows) {
    // 1行に2ペア（4列）ある形式を想定
    const key1 = row[0] ? row[0].trim() : '';
    const val1 = row[1] ? row[1].trim() : '';
    const key2 = row[3] ? row[3].trim() : '';
    const val2 = row[4] ? row[4].trim() : '';

    if (key1) {
      // 1列目がキー、2列目が値
      if (data[key1]) {
        data[key1] += '\n' + val1; // 既にあるキーなら改行で追記
      } else {
        data[key1] = val1;
      }
      lastKey = key1;
    } else if (lastKey && val1) {
      // 1列目が空で2列目に値があれば、直前の項目の改行とみなす
      data[lastKey] += '\n' + val1;
    }
    
    if (key2) {
      // 4列目がキー、5列目が値
      if (data[key2]) {
        data[key2] += '\n' + val2;
      } else {
        data[key2] = val2;
      }
      lastKey = key2;
    } else if (lastKey && val2) {
      // 4列目が空で5列目に値があれば、直前の項目の改行とみなす
      data[lastKey] += '\n' + val2;
    }
  }
  return data;
}

// フォームに入力データを送信する
function fillForm(data) {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, {
      action: 'fillForm',
      data: data
    });
  });
}
